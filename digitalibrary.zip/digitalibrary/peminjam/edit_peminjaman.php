<?php
	include 'header.php';
	include 'navbar.php';
?>
<?php 
include '../koneksi.php';
$PeminjamanID = $_GET['PeminjamanID'];
$data = mysqli_query($koneksi,"SELECT * FROM  peminjaman INNER JOIN user ON peminjaman.UserID=user.UserID INNER JOIN buku ON peminjaman.BukuID=buku.BukuID WHERE peminjaman.PeminjamanID=" . $_GET['PeminjamanID']);
while($d_koleksi = mysqli_fetch_array($data)){ 
    ?>
<div class="content mt-3">
	<div class="card">
		<div class="card-body">
            <form method="post" action="proses_update_peminjaman.php">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="Username" disabled value="<?=$_SESSION['Username']?>">
                    <input type="hidden" class="form-control" name="UserID" value="<?=$_SESSION['UserID']?>">
                    <input type="hidden" class="form-control" name="PeminjamanID" value="<?=$PeminjamanID?>">
                </div>
                <div class="form-group">
                    <label>Pilih Buku</label>
                    <input type="hidden" name="KategoriID" value="<?php echo $d_koleksi['KategoriID']; ?>">
                    <select class="form-control mt-2" name="BukuID">
                        <option>Silahkan Pilih</option>
                    <?php 
		            include '../koneksi.php';
		            $data = mysqli_query($koneksi,"select * from buku");
		            while($d_buku = mysqli_fetch_array($data)){?>
                        <option value="<?php echo $d_buku['BukuID']; ?>" <?php if ($d_buku['BukuID'] == $d_koleksi['BukuID']) {echo "selected";} ?>><?php echo $d_buku['Judul']; ?></option>
                    <?php } ?> 
                    </select>
                </div>
                <div class="form-group">
                    <label>Tanggal Peminjaman</label>
                    <input type="date" class="form-control" value="<?php echo $d_koleksi['TanggalPeminjaman']; ?>" name="TanggalPeminjaman">
                </div>
                <div class="form-group">
                    <label>Tanggal Pengembaliann</label>
                    <input type="date" class="form-control" value="<?php echo $d_koleksi['TanggalPengembalian']; ?>" name="TanggalPengembalian">
                </div>
                <div class="form-group">
                    <label for="status_peminjaman">Status Peminjaman</label>
                    <?php $StatusPeminjaman = $d_koleksi['StatusPeminjaman']; ?>
                    <select name="StatusPeminjaman" class="form-control">
                        <!-- <option value="1" <?= ($StatusPeminjaman == '1') ? "selected": ""?> >Di Pinjam</option> -->
                        <option value="2" <?= ($StatusPeminjaman == '2') ? "selected": ""?>>Di Kembalikan</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="form-control btn btn-primary btn-sm mt-3">Simpan</button>
                </div>
            </form>
		</div>
	</div>
</div>
<?php } ?>

<?php
	include 'footer.php';
?>